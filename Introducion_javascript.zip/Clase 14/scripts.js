/* Para pedir un dato al usuario se puede usar prompt(mensaje) */

prompt('Introduzca su nombre')

/* Para imprimir un dato se puede usar console.log(dato) */

console.log(dato);

